#! /bin/bash
cd
cd dns2proxy
python /root/dns2proxy/dns2proxy.py
read
